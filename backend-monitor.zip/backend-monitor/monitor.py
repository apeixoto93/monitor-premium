import os
import time
import json
import smtplib
import logging
import anthropic
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from apscheduler.schedulers.blocking import BlockingScheduler

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
log = logging.getLogger(__name__)

TERMS = [
    "Premium Elevadores",
    "PremiumElevadores",
    "@PremiumElevadores",
    "Premium Elevadores Curitiba",
    "Premium Elevadores reclamação",
]

ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
ALERT_EMAIL       = os.environ["ALERT_EMAIL"]
SMTP_HOST         = os.environ.get("SMTP_HOST", "smtp.office365.com")
SMTP_PORT         = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER         = os.environ["SMTP_USER"]
SMTP_PASS         = os.environ["SMTP_PASS"]

client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

SEV_COLORS = {
    "critico":  "#ef4444",
    "negativo": "#f97316",
    "neutro":   "#6b7280",
    "positivo": "#22c55e",
}

def search_term(term: str) -> dict:
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
        system=(
            "Você é um agente de monitoramento de reputação online.\n"
            "Busque menções recentes ao termo fornecido (redes sociais, Reclame Aqui, "
            "Google Reviews, Facebook, Instagram, Twitter/X, TikTok, portais de notícias, fóruns).\n"
            "Responda APENAS com JSON válido, sem markdown:\n"
            '{"encontrou":true,"mencoes":[{"titulo":"...","fonte":"...","url":"url ou null",'
            '"sentimento":"critico|negativo|neutro|positivo","resumo":"1-2 frases","data_estimada":"..."}],'
            '"alerta_nivel":"verde|amarelo|vermelho","resumo_geral":"1 frase"}'
        ),
        messages=[{
            "role": "user",
            "content": f'Busque menções recentes a: "{term}". Foco em críticas, reclamações, exposições publicadas nas últimas 48h.'
        }],
    )
    text = "".join(b.text for b in response.content if b.type == "text")
    clean = text.replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


def send_alert_email(mentions: list, alert_level: str):
    nivel_label = {"amarelo": "⚠️ ATENÇÃO", "vermelho": "🚨 ALERTA CRÍTICO"}.get(alert_level, "")
    nivel_color = {"amarelo": "#f59e0b", "vermelho": "#ef4444"}.get(alert_level, "#6b7280")

    rows = ""
    for m in mentions:
        color = SEV_COLORS.get(m.get("sentimento", "neutro"), "#6b7280")
        url_html = f'<a href="{m["url"]}" style="color:#7c3aed">Ver publicação →</a>' if m.get("url") and m["url"] != "null" else ""
        rows += f"""
        <div style="border:1px solid #e5e7eb;border-left:4px solid {color};border-radius:8px;padding:16px;margin-bottom:12px;">
          <div style="font-weight:700;font-size:14px;color:#111;margin-bottom:4px">{m.get('titulo','')}</div>
          <div style="font-size:13px;color:#555;margin-bottom:8px">{m.get('resumo','')}</div>
          <div style="font-size:11px;color:#999">
            📍 {m.get('fonte','')} &nbsp;|&nbsp; 🕐 {m.get('data_estimada','')} &nbsp;|&nbsp; {url_html}
          </div>
        </div>"""

    html = f"""
    <div style="font-family:Inter,sans-serif;max-width:600px;margin:0 auto;background:#fff;">
      <div style="background:linear-gradient(135deg,#1a0a2e,#0f3460);padding:28px 32px;border-radius:12px 12px 0 0;">
        <div style="font-size:28px;margin-bottom:8px">🛡️</div>
        <div style="color:#fff;font-size:20px;font-weight:800">Monitor de Reputação</div>
        <div style="color:#94a3b8;font-size:13px;margin-top:4px">Premium Elevadores</div>
      </div>
      <div style="padding:28px 32px;">
        <div style="background:{nivel_color}15;border:1px solid {nivel_color}44;border-radius:8px;padding:14px 18px;margin-bottom:24px;">
          <div style="font-size:16px;font-weight:700;color:{nivel_color}">{nivel_label}</div>
          <div style="font-size:13px;color:#555;margin-top:4px">{len(mentions)} menção(ões) encontrada(s) em {datetime.now().strftime('%d/%m/%Y às %H:%M')}</div>
        </div>
        {rows}
        <div style="margin-top:24px;padding-top:20px;border-top:1px solid #e5e7eb;font-size:11px;color:#999;text-align:center;">
          Monitor automático Premium Elevadores • Verificação a cada 15 minutos
        </div>
      </div>
    </div>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"{nivel_label} — Menção encontrada sobre Premium Elevadores"
    msg["From"]    = SMTP_USER
    msg["To"]      = ALERT_EMAIL
    msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as s:
        s.starttls()
        s.login(SMTP_USER, SMTP_PASS)
        s.sendmail(SMTP_USER, ALERT_EMAIL, msg.as_string())

    log.info(f"E-mail de alerta enviado para {ALERT_EMAIL}")


def run_scan():
    log.info("=== Iniciando varredura ===")
    all_mentions = []
    max_alert    = "verde"

    for term in TERMS:
        log.info(f'Buscando: "{term}"')
        try:
            result = search_term(term)
            if result.get("encontrou") and result.get("mencoes"):
                for m in result["mencoes"]:
                    m["term"] = term
                all_mentions.extend(result["mencoes"])
                log.info(f'  ✓ {len(result["mencoes"])} menção(ões) — {result.get("resumo_geral","")}')
                nivel = result.get("alerta_nivel", "verde")
                if nivel == "vermelho":
                    max_alert = "vermelho"
                elif nivel == "amarelo" and max_alert != "vermelho":
                    max_alert = "amarelo"
            else:
                log.info(f"  ✓ Nada encontrado")
        except Exception as e:
            log.error(f"  ✗ Erro: {e}")
        time.sleep(2)

    log.info(f"Varredura concluída — {len(all_mentions)} menção(ões) | alerta: {max_alert}")

    if all_mentions and max_alert != "verde":
        try:
            send_alert_email(all_mentions, max_alert)
        except Exception as e:
            log.error(f"Erro ao enviar e-mail: {e}")


if __name__ == "__main__":
    log.info("Monitor Premium Elevadores iniciando...")
    run_scan()  # roda imediatamente ao iniciar
    scheduler = BlockingScheduler(timezone="America/Sao_Paulo")
    scheduler.add_job(run_scan, "interval", minutes=15)
    log.info("Agendador iniciado — verificação a cada 15 minutos")
    scheduler.start()
