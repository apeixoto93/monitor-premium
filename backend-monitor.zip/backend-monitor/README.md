# Monitor de Reputação — Premium Elevadores
## Backend 24h no Railway

### Variáveis de ambiente necessárias no Railway:

| Variável | Valor |
|----------|-------|
| `ANTHROPIC_API_KEY` | Sua chave sk-ant-... |
| `ALERT_EMAIL` | alisson.peixoto93@outlook.com |
| `SMTP_USER` | alisson.peixoto93@outlook.com |
| `SMTP_PASS` | Senha do Outlook (ou senha de app) |
| `SMTP_HOST` | smtp.office365.com |
| `SMTP_PORT` | 587 |

### Passos para deploy no Railway:

1. Acesse railway.app e crie conta gratuita
2. Clique em "New Project" → "Deploy from GitHub"
   - Ou use "Deploy from template" → suba os arquivos
3. Adicione as variáveis de ambiente acima
4. O serviço sobe automaticamente e roda 24h

### O que o monitor faz:
- Verifica a cada 15 minutos os termos:
  - "Premium Elevadores"
  - "PremiumElevadores"  
  - "@PremiumElevadores"
  - "Premium Elevadores Curitiba"
  - "Premium Elevadores reclamação"
- Se encontrar menções negativas/críticas, envia e-mail de alerta
- Logs completos disponíveis no painel do Railway
